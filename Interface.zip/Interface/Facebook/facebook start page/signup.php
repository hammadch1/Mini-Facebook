<?php
	$fn=$_POST["signup_firstname"];
	$sn=$_POST["signup_surname"];
	$e=$_POST["signup_email"];
	$p=$_POST["signup_password"];
	$dob = date('Y-m-d', strtotime($_POST['signup_dob']));
	$gender=$_POST["gender"];
	$q="Insert into user(fname,lname,email,password,dob) values('" . $fn . "','" . $sn . "','" . $e . "','" .  $p . "','" . $dob . "')";
	$user='root';
	$pass='';
	$dbname='facebook';
	$db=new mysqli('localhost',$user,$pass,$dbname) or die("Unable to connect");
	if(!$db)
		die('Connect Error('.mysql_errno().')'.mysql_error());
	else{
		//echo "DB: " . $dbname . " connected<br>";
	}
	// echo "First Name = " . $fn . "<br>";
	// echo "Surname = " . $sn . "<br>";
	// echo "Email = " . $e . "<br>";
	// echo "Password = ". $p . "<br>";
	// echo "DOB = " . $dob. "<br>";
	// echo "Gender = ". $gender . "<br>";
	// echo $q ."<br>";
	if($db->query($q) == true)
		echo "<script type='text/javascript'>alert('Your facebook user account has been created. Login to continue'); windows.location='signup.php';</script>";
	else
		echo $db->error;
	include("C:/xampp/php/pear/page1.html");
	
?>