<?php
	session_start();
	$data=$_POST["post_data"];
	$date=date('Y/m/d H:i:s');
	//$q="insert into post(data,date_time) values('" . $data . "','" . $date . "')";
	$q="insert into post(data,date_time) values('" . '' . "','" . $date . "')";
	$user='root';
	$pass='';
	$dbname='facebook';
	$db=new mysqli('localhost',$user,$pass,$dbname) or die("Unable to connect");
	if(!$db)
		die('Connect Error('.mysql_errno().')'.mysql_error());
	if($db->query($q) == true)
	{
		$q="select pid from post where Data='" . ''. "'";
		//echo $q . "<br>";
		$res2=$db->query($q);
		$postid=mysqli_fetch_row($res2); //$postid[0] is pid
		$q="insert into user_post(post_id,uid) values(" . $postid[0] . "," . $_SESSION["userid"] . ")";
		//echo $q. "<br>";
		$db->query($q);
		$q="update post set Data='". $data ."' where pid = ". $postid[0] . "";
		//echo $q;
		$db->query($q);
		echo "<script type='text/javascript'>alert('Post Successful !'); windows.location='post.php';</script>";
	}	
	else
		echo $db->error;
	include("C:/xampp/php/pear/page2.php");
?>