<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Facebook</title>


    <link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="css/bootstrap-grid.css"/>
    <link type="text/css" rel="stylesheet" href="css/bootstrap-grid.min.css"/>
    <link type="text/css" rel="stylesheet" href="css/bootstrap-reboot.css"/>
    <link type="text/css" rel="stylesheet" href="css/bootstrap-reboot.min.css"/>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="stylesheet" type="text/css" href="page3.css"/>

    <link rel="shortcut icon" href="img/icon.png">

</head>
<body>

<div class="row" style="height: 42px;">

    <div class="col-md-6" style="background-color: rgb(61,91,153); height: 42px;">
            <div class="input-group" style="width: 400px; margin-top: 9px; margin-left: 190px;">
                <input type="text" class="form-control" placeholder="Search" style="height:25px;">
                <div class="input-group-append">
                <button class="btn btn-secondary" type="button" style="height:25px;">
                 <i class="fa fa-search" style="height:30px;"></i>
                 </button>
                </div>
            </div>
    </div>

    <div class="col-md-6" style="background-color: rgb(61,91,153); height: 42px;">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

        <div style="height: 30px;">
            <ul>
                <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page3.php';"><?php session_start(); echo $_SESSION["name"]?></a></li>
                <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page2.php';">Home</a></li>
                <li><a href="#">Find Friends</a></li>
                <li><a href="#">Messages</a></li>
                <li id="noti_Container">
                    <div id="noti_Counter"></div> 
                    <div id="noti_Button"></div>    

                  
                    <div id="notifications">
                        <h3>Notifications</h3>
                        <div style="height:100px; width: 30px;"></div>
                        <div class="seeAll"><a href="#">See All</a></div>
                    </div>
                </li>
                <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page1.html';">Log Out</a></li>
            </ul>
        </div>
    </div>
    
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="fb-profile-block">
                <div class="fb-profile-block-thumb cover-container"></div>
                <div class="profile-img">
                    <a href="#">
                        <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="" title="">        
                    </a>
                </div>
                <div class="profile-name">
                    <h2><?php echo $_SESSION["name"]; ?></h2>
                </div>
                
                <div class="fb-profile-block-menu">
                    <div class="block-menu">
                        <ul>
                            <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page3.php';" onc>Timeline</a></li>
                            <li><a href="#">about</a></li>
                            <li><a href="#">Friends</a></li>
                            <li><a href="#">Photos</a></li>
                            <li><a href="#">More...</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>