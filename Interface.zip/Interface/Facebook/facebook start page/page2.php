<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Facebook</title>


	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>
	<link type="text/css" rel="stylesheet" href="css/bootstrap-grid.css"/>
	<link type="text/css" rel="stylesheet" href="css/bootstrap-grid.min.css"/>
	<link type="text/css" rel="stylesheet" href="css/bootstrap-reboot.css"/>
	<link type="text/css" rel="stylesheet" href="css/bootstrap-reboot.min.css"/>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css"/>

	<link rel="shortcut icon" href="img/icon.png">
<script>
	function post_validation_check()
	{
		if(document.getElementById("post_data").value=='')
		{
			alert("Insert data in post please");
			return false;
		}
	}
</script>
</head>
<body>
<div class="row" style="height: 42px;">

	<div class="col-md-6" style="background-color: rgb(61,91,153);">
            <div class="input-group" style="width: 400px; margin-top: 9px; margin-left: 190px;">
    			<input type="text" class="form-control" placeholder="Search" style="height:25px;">
   			 	<div class="input-group-append">
      			<button class="btn btn-secondary" type="button" style="height:25px;">
       			 <i class="fa fa-search" style="height:30px;"></i>
     			 </button>
    			</div>
  			</div>
	</div>

	<div class="col-md-6" style="background-color: rgb(61,91,153);">
		<!--<div style="margin-right: 20px; height: 28px;margin-top: 7px;" class="btn-group" role="group" aria-label="Basic example" >
		  <button style="border-color:rgb(61,91,123);  background-color:rgb(61,91,153);" type="button" class="btn btn-primary">Username</button>
		  <button style="border-color:rgb(61,91,123);background-color:rgb(61,91,153);"type="button" class="btn btn-primary">Home</button>
		  <button style="border-color:rgb(61,91,123);background-color:rgb(61,91,153);"type="button" class="btn btn-primary">Find Friends</button>
		  <button style="border-color:rgb(61,91,123);background-color:rgb(61,91,153);"type="button" class="btn btn-primary">Create</button>
		</div>-->

	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

	    <div>
	        <ul>
	        	<li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page3.php';"><?php session_start(); echo $_SESSION["name"]?></a></li>
	            <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page2.php';">Home</a></li>
	            <li><a href="#">Find Friends</a></li>
	            <li><a href="#">Messages</a></li>
	            <li id="noti_Container">
	                <div id="noti_Counter"></div>   <!--SHOW NOTIFICATIONS COUNT.-->
	                
	                <!--A CIRCLE LIKE BUTTON TO DISPLAY NOTIFICATION DROPDOWN.-->
	                <div id="noti_Button"></div>    

	                <!--THE NOTIFICAIONS DROPDOWN BOX.-->
	                <div id="notifications">
	                    <h3>Notifications</h3>
	                    <div style="height:100px; width: 30px;"></div>
	                    <div class="seeAll"><a href="#">See All</a></div>
	                </div>
	            </li>
	            <li><a href="#" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page1.html';">Log Out</a></li>
	        </ul>
	    </div>
	</div>
	
</div>

<div class="row" style="height: 900px;border-top: 1px solid black;">
	<div class="col-md-2" style="height: 900px;">
		<button type="button"  class="btn btn-outline-light text-dark btn-sm" style="width: 185px; height:29px;margin-left: 62px; margin-top: 10px;" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page3.php';"><?php echo $_SESSION["name"] ?></button>
		<button type="button" class="btn btn-outline-light text-dark btn-sm" onclick="window.location.href = 'http://localhost/Facebook/facebook%20start%20page/page2.php';" style="width: 185px;height:29px; margin-left: 62px; margin-top: 10px;">News Feed</button>
		<label for="Explore" style="margin-left: 62px; margin-top: 15px; color: grey; font-size: 15px;font-weight: bold;">Explore</label>
		<button type="button" class="btn btn-outline-light text-dark btn-sm" style="width: 185px;height:29px; margin-left: 62px; ">Pages</button>
		<button type="button" class="btn btn-outline-light text-dark btn-sm" style="width: 185px;height:29px; margin-left: 62px;">Groups</button>
	</div>
	<div class="container bootstrap snippet">
    <div class="row" style="margin-left: 30px; margin-top: 20px;">
        <div class="col-md-offset-3 col-md-6 col-xs-12" style="margin-top: 5PX;">
            <div class="well well-sm well-social-post">
        		<form action="post.php" method="POST" onsubmit="return post_validation_check();">
            <!-- <ul class="list-inline" id='list_PostActions'>
                <li ><a href='#'>Add photos/Video</a></li>
            </ul> -->
            <textarea id="post_data" name="post_data" style="margin-top: 10px;" class="form-control" placeholder="What's on your mind?"></textarea>
            <ul class='list-inline post-actions'>
                <li  type="submit" class='pull-right' ><button type="submit" class="button btn-success" style="background-color: rgb(61,91,153); font-size: 14px;">Post</button></li>
            </ul>
        </form>
            </div>
        </div>
    </div>
	</div>   
</div>
	<!--<section>
	<div class="col-md-6" style="height: 900px;margin-top: 30px;">
	  <div class="container" style="margin-right: 40px;">   
	    
	    <div class="box text">
	      <div class="box-header">
	        <h3><a href=""><img src="https://scontent.flhe7-1.fna.fbcdn.net/v/t1.0-9/44931900_1781377571969816_5015973347289202688_n.jpg?_nc_cat=101&_nc_ht=scontent.flhe7-1.fna&oh=b6bef2979b2ad648536996aa7e003fef&oe=5D7B4B8D" alt="" />Muhammad Hammad Chaudhary</a>
	          <span>March 21,18:45pm <i class="fa fa-globe"></i></span>
	        </h3>
	        <span><i class="ion-more"></i></span>
	        <div class="window"><span></span></div>
	      </div>
	      <div class="box-content">
	        <div class="content">
	          <p>Lorem ipsum ad his scripta blandit partiendo, eum fastidii accumsan euripidis in, eum liber hendrerit an. Qui ut wisi vocibus suscipiantur, quo dicit ridens inciderint id. Quo mundi lobortis reformidans eu, legimus senserit definiebas an eos.</p>
	        </div>
	      </div>
	      <div class="box-likes">
	        <div class="row">
	          <span><a href="#"><img src="https://goo.gl/oM0Y8G" alt="" /></a></span>
	          <span><a href="#"><img src="https://goo.gl/vswgSn" alt="" /></a></span>
	          <span><a href="#"><img src="https://goo.gl/4W27eB" alt="" /></a></span>
	          <span><a href="#">+99</a></span>
	          <span>Like this -</span>
	        </div>
	        <div class="row">
	          <span> 145 comments</span>
	        </div>
	      </div>
	      <div class="box-buttons">
	        <div class="row">
	          <button><span class="fa fa-thumbs-up"></span> Like</button>
	          <button><span class="ion-chatbox-working"></span> Comment</button>
	        </div>
	      </div>
	      <div class="box-click"><span><i class="ion-chatbox-working"></i> View 140 more comments</span></div>
	      <div class="box-comments">
	        <div class="comment"><img src="https://goo.gl/oM0Y8G" alt="" />
	          <div class="content">
	            <h3><a href="">Emily Rudd</a><span><time> 1 hr - </time><a href="#">Like</a></span></h3>
	            <p>Lorem ipsum ad his scripta blandit partiendo, :D loll </p>
	          </div>
	        </div>
	        <div class="comment"><img src="https://goo.gl/vswgSn" alt="" />
	          <div class="content">
	            <h3><a href="">barbara Palvin</a><span><time> 1 hr - </time><a href="#">Like</a></span></h3>
	            <p>Lorem ipsum ad his scripta blandit partiendo</p>
	          </div>
	        </div>
	        <div class="comment"><img src="https://goo.gl/4W27eB" alt="" />
	          <div class="content">
	            <h3><a href="">Erica Mohn</a><span><time> 1 hr - </time><a href="#">Like</a></span></h3>
	            <p>Lorem ipsum ad his scripta blandit partiendo, pro :D</p>
	          </div>
	        </div>
	        <div class="comment"><img src="https://goo.gl/zX8wpb" alt="" />
	          <div class="content">
	            <h3><a href="">karlie Kloss</a><span><time> 1 hr - </time><a href="#">Like</a></span></h3>
	            <p>I like the Lorem ipsum ad his scripta blandit partiendo <3 lovely</p>
	          </div>
	        </div>
	        <div class="comment"><img src="https://goo.gl/K7E2k4" alt="" />
	          <div class="content">
	            <h3><a href="">Candice Swanepoel</a><span><time> 1 hr - </time><a href="#">Like</a></span></h3>
	            <p>:) Lorem ipsum ad his scripta blandit partiendo</p>
	          </div>
	        </div>
	      </div>
	        <div class="box-new-comment">
	          <img src="https://goo.gl/oOD0V2" alt="" />
	          <div class="content">
	            <div class="row">
	              <textarea placeholder="write a comment..."></textarea>
	            </div>
	            <div class="row">
	              <span class="ion-android-attach"></span>
	              <span class="fa fa-smile-o"></span>
	            </div>
	          </div>
	        </div>
	    </div>    
	    
	  </div>
	</div>
</section>-->
<!--<footer>
  <h4>Thank You</h4>
  <p>Made <a href="https://twitter.com/roswellparian" target="_blank">@roswellparian</a> by Parian</p>
</footer>-->
</body>

</html>