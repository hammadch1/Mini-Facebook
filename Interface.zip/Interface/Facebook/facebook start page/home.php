<?php

session_start();
echo $_SESSION["email"];
// echo "<button type='button' class='tn btn-outline-light text-dark btn-sm' style='width: 185px; height:29px;margin-left: 62px; margin-top: 10px;'>$_SESSION["email"]</button>";
// echo "<script type='text/javascript'>alert('Wrong username or password'); windows.location='login.php'; </script>";

?>