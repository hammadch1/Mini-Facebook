<?php
session_start();
$user='root';
$pass='';
$dbname='facebook';
$db=new mysqli('localhost',$user,$pass,$dbname) or die("Unable to connect");
if(!$db)
	die('Connect Error('.mysql_errno().')'.mysql_error());
	
$e=$_POST["email"];
$p=$_POST["password"];


$q="select * from user where email='" . $e. "' and password='".$p ."'";
$res = $db->query($q);
do
{
	//echo $q;

	if(!($res->fetch_assoc()))
	{
		echo "<script type='text/javascript'>alert('Wrong username or password'); windows.location='login.php'; </script>";
		include("C:/xampp/php/pear/page1.html");
	}
	else
	{
		while ($r=$res->fetch_assoc()) 
		{
			$n=$r["fname"]." ".$r["lname"];
			$s=$r["status"];
			$img_src=$r["dp_url"];
			$dob=$r["dob"];
			$_SESSION["name"]=$n;
				echo $n." ".$e." ".$p." ".$s." "."<br>".$img_src."<br>".$dob."<br>";
		}
	}
}
while ($res->fetch_assoc());
$nameq="select fname,lname from user where email='" . $e. "' and password='".$p ."'";
$uidq="select uid from user where email='" . $e. "' and password='".$p ."'";
$res1=$db->query($uidq);
$res2=$db->query($nameq);
$uid=mysqli_fetch_row($res1);
$temp=mysqli_fetch_row($res2);
$name=$temp[0]." ".$temp[1];
$_SESSION["userid"]=$uid[0];
$_SESSION["name"]=$name;
$_SESSION["email"]=$e;
include("C:/xampp/php/pear/page2.php");

?>